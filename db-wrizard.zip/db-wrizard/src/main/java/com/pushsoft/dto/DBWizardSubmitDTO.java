package com.pushsoft.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Created by naveenkumtakar on 24/07/2016.
 */
public class DBWizardSubmitDTO implements Serializable{
    private List<String> selectedFeatures;

    public List<String> getSelectedFeatures() {
        return selectedFeatures;
    }

    public void setSelectedFeatures(List<String> selectedFeatures) {
        this.selectedFeatures = selectedFeatures;
    }
}
