package com.pushsoft.dto;

import java.io.Serializable;

/**
 * Created by naveenkumtakar on 24/07/2016.
 */
public class DBWizardResultsDTO implements Serializable{
    private String databaseName;
    private Double totalPointsEarned;

    public DBWizardResultsDTO() {
    }

    public DBWizardResultsDTO(String databaseName, Double totalPointsEarned) {
        this.databaseName = databaseName;
        this.totalPointsEarned = totalPointsEarned;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public Double getTotalPointsEarned() {
        return totalPointsEarned;
    }

    public void setTotalPointsEarned(Double totalPointsEarned) {
        this.totalPointsEarned = totalPointsEarned;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DBWizardResultsDTO that = (DBWizardResultsDTO) o;

        if (databaseName != null ? !databaseName.equals(that.databaseName) : that.databaseName != null) return false;
        return totalPointsEarned != null ? totalPointsEarned.equals(that.totalPointsEarned) : that.totalPointsEarned == null;

    }

    @Override
    public int hashCode() {
        int result = databaseName != null ? databaseName.hashCode() : 0;
        result = 31 * result + (totalPointsEarned != null ? totalPointsEarned.hashCode() : 0);
        return result;
    }
}
