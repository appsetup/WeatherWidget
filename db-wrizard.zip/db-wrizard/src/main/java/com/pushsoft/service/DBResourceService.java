package com.pushsoft.service;

import com.pushsoft.dao.DBMetaDataDAO;
import com.pushsoft.dto.DBWizardResultsDTO;
import com.pushsoft.entity.DBMetadata;

import java.util.List;

/**
 * Created by naveenkumtakar on 23/07/2016.
 */
public class DBResourceService implements Service<DBMetadata,DBWizardResultsDTO>{

    public DBResourceService(DBMetaDataDAO metaDataDAO) {
        this.metaDataDAO = metaDataDAO;
    }

    private DBMetaDataDAO metaDataDAO = null;
    @Override
    public List<DBMetadata> findAll() {
        return metaDataDAO.findAll();
    }

    @Override
    public List<DBWizardResultsDTO> getResults(List<String> selectedFeatures) {
        return metaDataDAO.getResults(selectedFeatures);
    }


    public List<String>  findAllFeatureCategory(){
        return metaDataDAO.getAllFeatureCategories();
    }

    public List<String> findAllFeaturesByFeatureCategory(String featureCategory)
    {
        return metaDataDAO.getFeaturesByFeatureCategory(featureCategory);
    }


}
