package com.pushsoft.service;

import javassist.bytecode.stackmap.TypeData;

import java.util.List;

/**
 * Created by naveenkumtakar on 23/07/2016.
 */
public interface Service<T,M> {
    List<T> findAll();

    public <V> List<V>  findAllFeatureCategory();

    public <V> List<V> findAllFeaturesByFeatureCategory(String featureCategory);

    public List<M> getResults(List<String> selectedFeatures);
}
