package com.pushsoft.dao;

import com.pushsoft.dto.DBWizardResultsDTO;
import com.pushsoft.entity.DBMetadata;
import io.dropwizard.hibernate.AbstractDAO;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.*;
import org.hibernate.transform.AliasToBeanResultTransformer;

import java.util.List;

/**
 * Created by naveenkumtakar on 23/07/2016.
 */
public class DBMetaDataDAO extends AbstractDAO<DBMetadata> {

    public DBMetaDataDAO(SessionFactory sessionFactory) {
        super(sessionFactory);
    }

    public List<DBMetadata> findAll()
    {
        return criteria().list();
    }

    public List<String> getAllFeatureCategories()
    {
        return criteria().setProjection(Projections.distinct(Projections.property("featureCategory"))).list();
    }

    public List<String> getFeaturesByFeatureCategory(String featureCategory)
    {
        return criteria().setProjection(Projections.distinct(Projections.property("feature"))).add(Restrictions.eq("featureCategory",featureCategory)).list();
    }

    public List<DBWizardResultsDTO> getResults(List<String> selecedFeatures)
    {
        return criteria().add(Restrictions.in("feature",selecedFeatures))
                .setProjection(Projections.projectionList()
                .add(Projections.groupProperty("databaseName").as("databaseName"))
                .add(Projections.sum("points").as("totalPointsEarned"))).setResultTransformer(new AliasToBeanResultTransformer(DBWizardResultsDTO.class)).list();
    }
}
