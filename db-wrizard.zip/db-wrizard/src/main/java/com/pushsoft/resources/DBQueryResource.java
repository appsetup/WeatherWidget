package com.pushsoft.resources;

import com.pushsoft.dto.DBWizardResultsDTO;
import com.pushsoft.dto.DBWizardSubmitDTO;
import com.pushsoft.entity.DBMetadata;
import com.pushsoft.service.DBResourceService;
import com.pushsoft.service.Service;
import io.dropwizard.hibernate.UnitOfWork;

import javax.ws.rs.*;
import java.util.List;
import java.util.Map;

/**
 * Created by naveenkumtakar on 23/07/2016.
 */
@Path("/db-query")
public class DBQueryResource {

    public DBQueryResource(Service<DBMetadata,DBWizardResultsDTO> dbResourceService) {
        this.dbResourceService = dbResourceService;
    }

    private Service<DBMetadata,DBWizardResultsDTO> dbResourceService = null;

    @GET
    @Path("/all")
    @Produces({"application/json"})
    @UnitOfWork
    public List<DBMetadata> getAllDBs()
    {
        return dbResourceService.findAll();
    }


    @GET
    @Path("/featureCategory")
    @Produces({"application/json"})
    @UnitOfWork
    public List<String> getAllFeatureCategory()
    {
        return dbResourceService.findAllFeatureCategory();
    }

    @GET
    @Path("/feature/{featureCategory}")
    @Produces("application/json")
    @UnitOfWork
    public List<String> getAllFeaturesByFeatureCategory(@PathParam("featureCategory") String featureCategory)
    {
        return dbResourceService.findAllFeaturesByFeatureCategory(featureCategory);
    }

    @POST
    @Path("/submit")
    @Produces("application/json")
    @Consumes("application/json")
    @UnitOfWork
    public List<DBWizardResultsDTO> submitResults(DBWizardSubmitDTO selectedFestures)
    {
        return dbResourceService.getResults(selectedFestures.getSelectedFeatures());
    }
}
