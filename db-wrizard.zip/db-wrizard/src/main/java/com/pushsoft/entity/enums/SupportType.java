package com.pushsoft.entity.enums;

/**
 * Created by naveenkumtakar on 23/07/2016.
 */
public enum SupportType {
    Y,N,P;
}
