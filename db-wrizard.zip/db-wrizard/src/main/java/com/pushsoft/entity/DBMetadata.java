package com.pushsoft.entity;

import com.pushsoft.entity.enums.SupportType;

import javax.persistence.*;

/**
 * Created by naveenkumtakar on 23/07/2016.
 */
@IdClass(DBMetadataPK.class)
@Entity(name = "DB_METADATA")
public class DBMetadata {
    @Id
    @Column(name = "Database_name")
    private String databaseName;

    @Id
    @Column(name = "Feature_Category")
    private String featureCategory;

    @Id
    @Column(name = "Feature")
    private String feature;

    @Column(name="Supported")
    @Enumerated(value = EnumType.STRING)
    private SupportType supportType;

    @Column(name = "Points")
    private Double points;

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getFeatureCategory() {
        return featureCategory;
    }

    public void setFeatureCategory(String featureCategory) {
        this.featureCategory = featureCategory;
    }

    public String getFeature() {
        return feature;
    }

    public void setFeature(String feature) {
        this.feature = feature;
    }

    public SupportType getSupportType() {
        return supportType;
    }

    public void setSupportType(SupportType supportType) {
        this.supportType = supportType;
    }

    public Double getPoints() {
        return points;
    }

    public void setPoints(Double points) {
        this.points = points;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DBMetadata that = (DBMetadata) o;

        if (databaseName != null ? !databaseName.equals(that.databaseName) : that.databaseName != null) return false;
        if (featureCategory != null ? !featureCategory.equals(that.featureCategory) : that.featureCategory != null)
            return false;
        return feature != null ? feature.equals(that.feature) : that.feature == null;

    }

    @Override
    public int hashCode() {
        int result = databaseName != null ? databaseName.hashCode() : 0;
        result = 31 * result + (featureCategory != null ? featureCategory.hashCode() : 0);
        result = 31 * result + (feature != null ? feature.hashCode() : 0);
        return result;
    }
}
