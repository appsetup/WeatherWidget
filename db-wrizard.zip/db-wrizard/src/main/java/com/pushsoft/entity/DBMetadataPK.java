package com.pushsoft.entity;

import java.io.Serializable;

/**
 * Created by naveenkumtakar on 23/07/2016.
 */
public class DBMetadataPK  implements Serializable{

    private String databaseName;

    private String featureCategory;

    private String feature;

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getFeatureCategory() {
        return featureCategory;
    }

    public void setFeatureCategory(String featureCategory) {
        this.featureCategory = featureCategory;
    }

    public String getFeature() {
        return feature;
    }

    public void setFeature(String feature) {
        this.feature = feature;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DBMetadataPK that = (DBMetadataPK) o;

        if (databaseName != null ? !databaseName.equals(that.databaseName) : that.databaseName != null) return false;
        if (featureCategory != null ? !featureCategory.equals(that.featureCategory) : that.featureCategory != null)
            return false;
        return feature != null ? feature.equals(that.feature) : that.feature == null;

    }

    @Override
    public int hashCode() {
        int result = databaseName != null ? databaseName.hashCode() : 0;
        result = 31 * result + (featureCategory != null ? featureCategory.hashCode() : 0);
        result = 31 * result + (feature != null ? feature.hashCode() : 0);
        return result;
    }
}

