package com.pushsoft;

import com.pushsoft.dao.DBMetaDataDAO;
import com.pushsoft.dto.DBWizardResultsDTO;
import com.pushsoft.entity.DBMetadata;
import com.pushsoft.resources.DBQueryResource;
import com.pushsoft.service.DBResourceService;
import com.pushsoft.service.Service;
import io.dropwizard.Application;
import io.dropwizard.assets.AssetsBundle;
import io.dropwizard.db.PooledDataSourceFactory;
import io.dropwizard.hibernate.HibernateBundle;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

public class DBWizardApplication extends Application<DBWizardConfiguration> {
    private HibernateBundle<DBWizardConfiguration> hibernateBundle;

    public static void main(final String[] args) throws Exception {
        new DBWizardApplication().run(args);
    }

    @Override
    public String getName() {
        return "db-wizard";
    }

    @Override
    public void initialize(final Bootstrap<DBWizardConfiguration> bootstrap) {
        hibernateBundle = new HibernateBundle<DBWizardConfiguration>(DBMetadata.class) {
            @Override
            public PooledDataSourceFactory getDataSourceFactory(DBWizardConfiguration dbWizardConfiguration) {
                return dbWizardConfiguration.getDataSourceFactory();
            }
        };
        bootstrap.addBundle(hibernateBundle);
        bootstrap.addBundle(new AssetsBundle("/assets","/db-wizard","db-wizard.html"));
        bootstrap.addBundle(new AssetsBundle("/assets/js","/js",null,"js"));
        bootstrap.addBundle(new AssetsBundle("/assets/css","/css",null,"css"));


    }

    @Override
    public void run(final DBWizardConfiguration configuration,
                    final Environment environment) {
        DBMetaDataDAO dbMetaDataDAO = new DBMetaDataDAO(hibernateBundle.getSessionFactory());
        Service<DBMetadata,DBWizardResultsDTO> dbMetadataService = new DBResourceService(dbMetaDataDAO);
        JerseyEnvironment jersey = environment.jersey();
        jersey.register(new DBQueryResource(dbMetadataService));
    }

}
