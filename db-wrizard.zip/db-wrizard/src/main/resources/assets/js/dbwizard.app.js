(function ()
{
    "use strict";

    var app = angular.module("dbwizard", ["ngAnimate"]);
}());