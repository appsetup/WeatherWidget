(function ()
{
    "use strict";

    var directive = function ($http)
    {
        function link($scope, element, attributes, controller)
        {
            var page = $scope.pages[$scope.selectedPageId];
            $scope.title = page;

            console.log("Directive [page].[" + page + "] loaded.");
        }

        return {
            restrict: "EA",
            link: link
        };
    };

    angular.module("dbwizard").directive("page", ["$http",directive]);
}());