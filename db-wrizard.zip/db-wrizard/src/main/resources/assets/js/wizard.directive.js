(function ()
{
    "use strict";

    var directive = function ($http)
    {
        function link($scope,element, attributes, controller)
        {
            function initialize()
            {
                populatePages();

            }

            function showPage(pageId)
            {
                $scope.selectedPageId = pageId;
                var page = $scope.pages[$scope.selectedPageId];
                $scope.setPageTemplateUrl(page);
                getAllFeatures(page);
            }

            function getAllFeatures(page)
            {
            $http.get(
                              'db-query/feature/'+page
                            ).then(function (response) {
                                $scope.features=response.data;
                                console.log(response.data);
                              },function (response) {
                                // called asynchronously if an error occurs
                                // or server returns response with an error status.
                              });
            }
            function populatePages()
            {
                $http.get(
                  'db-query/featureCategory'
                ).then(function (response) {
                    $scope.pages= response.data;
                    if($scope.pages.length > 0)
                    {
                        showPage(0);
                    }
                    console.log(response.data);
                  },function (response) {
                    // called asynchronously if an error occurs
                    // or server returns response with an error status.
                  });
            }
                    $scope.pages = [];
                    $scope.features = [];

//            $scope.pages = [
//                {
//                    title: "intro"
//                }
//            ];

            $scope.isActive = function (page)
            {
                var selectedPage = $scope.pages[$scope.selectedPageId];
                return (selectedPage.title === page.title);
            };

            $scope.isCompleted = function (page)
            {
                var index = $scope.pages.indexOf(page);
                return (index < $scope.selectedPageId);
            };

            $scope.next = function ()
            {
                showPage($scope.selectedPageId + 1);
            };

            $scope.prev = function ()
            {
                showPage($scope.selectedPageId - 1);
            };

            $scope.showResult = function ()
            {
                $scope.nextPrevEnabled = true;
                var selectedFeatures = [];
                for(var feature in $scope.selectedFeature)
                 {
                    selectedFeatures.push(feature)
                 }
                $http.post('db-query/submit',{selectedFeatures})
                .then(function (response) {
                   $scope.results = response.data;
                   $scope.pageTemplateUrl = "db-wizard/results.html";
                   console.log(response.data);
                 },function (response) {
                   // called asynchronously if an error occurs
                   // or server returns response with an error status.
                 });

            }

            $scope.startOver = function()
            {
                $scope.nextPrevEnabled = false;
                showPage(0);

            }

            $scope.isNextPrevDisabled = function()
            {
                return $scope.nextPrevEnabled;
            }

            $scope.nextShouldBeDisabled = function ()
            {
                return ($scope.selectedPageId >= $scope.pages.length - 1);
            };

            $scope.prevShouldBeDisabled = function ()
            {
                return ($scope.selectedPageId <= 0);
            };

            $scope.setPageTemplateUrl = function (page)
            {
                var index = $scope.pages.indexOf(page);
                if (index <= $scope.selectedPageId)
                {
                    $scope.selectedPageId = index;
                    $scope.pageTemplateUrl = "db-wizard/intro.html?"+index;
                }
            };

            initialize();

            console.log("Directive [wizard] loaded.");
        }

        return {
            restrict: "EA",
            link: link,
            templateUrl: "db-wizard/wizard.html"
        };
    };

    angular.module("dbwizard").directive("wizard", ["$http",directive]);
}());