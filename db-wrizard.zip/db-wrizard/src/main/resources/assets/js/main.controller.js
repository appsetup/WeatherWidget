(function ()
{
    "use strict";

    var app = angular.module("dbwizard",["googlechart"]);

    var controller = function ($scope)
    {
        console.log("Controller [main] loaded.");
        $scope.title = "Modern Data Platform - Comparison";
    };

    app.controller("main", ["$scope", "$http",controller]);
}());