(function ()
{
    "use strict";

    var app = angular.module("dbwizard");

    var controller = function ($scope)
    {
        console.log("Controller [main] loaded.");
        $scope.title = "Dynamic loading of views as directives in a AngularJS wizard.";
    };

    app.controller("main", ["$scope", "$http",controller]);
}());